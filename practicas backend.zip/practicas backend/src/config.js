//Variables Globales
require("dotenv").config()

module.exports = {
    app : {
        port : process.env.PORT || 4000//puerto
    },
    mysql : {
        host : process.env.MYSQL_HOST || "loacalhost",
        user : process.env.MYSQL_USER || "root",
        password : process.env.MYSQL_PASSWORD || "",
        database : process.env.MYSQL_DB || "ejemplo",
    }
}  