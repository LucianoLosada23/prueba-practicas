const express = require("express");
const respuesta = require("../../red/respuesta");
const controlador = require("./index");
const router = express.Router();



module.exports = router;
