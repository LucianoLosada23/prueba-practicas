const express = require("express");
const config = require("./config");
const morgan = require("morgan");
const cors = require("cors");
const app = express();
const roles = require("./modulos/roles/rutas");
const usuarios = require("./modulos/usuarios/rutas");
const error = require("./red/error");

// Configuración de CORS
app.use(cors({
    origin: 'http://localhost:5173', // Permite solicitudes solo desde este origen
    methods: ['GET', 'POST', 'PUT', 'DELETE'], // Métodos permitidos
    allowedHeaders: ['Content-Type', 'Authorization'] // Encabezados permitidos
}));

// Middleware
app.use(morgan("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Configuración del puerto
app.set("port", config.app.port);

// Rutas
app.use("/api/roles", roles);
app.use("/api/usuarios", usuarios);

// Middleware de manejo de errores
app.use((err, req, res, next) => {
    console.error(err.stack); // Log the error
    res.status(err.statusCode || 500).json({
        error: err.message || 'Internal Server Error'
    });
});

module.exports = app;
