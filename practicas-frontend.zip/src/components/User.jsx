import React from 'react'

export default function User() {
  const handleSubmit = (event) => {
    event.preventDefault();
  };
  return (
    <>
     <div className='border border-gray-700 p-4 max-w-lg mx-auto mt-28'>
      <h1 className='text-2xl font-bold mb-4 text-center'>Crear un Usuario</h1>
      <form className='flex flex-col space-y-4' onSubmit={handleSubmit}>
        <div>
          <input
            id="username"
            type="text"
            placeholder='Enter user name'
            className='border border-gray-300 rounded p-2 w-full'
            required
          />
        </div>
        <div>
          <input
            id="email"
            type="email"
            placeholder='Enter email'
            className='border border-gray-300 rounded p-2 w-full'
            required
          />
        </div>
        <div>
          <input
            id="password"
            type="password"
            placeholder='Enter password'
            className='border border-gray-300 rounded p-2 w-full'
            required
          />
        </div>
        <div>
          <input
            id="phone"
            type="number"
            placeholder='Enter phone number'
            className='border border-gray-300 rounded p-2 w-full'
            required
          />
        </div>
        <div>
          <select
            id="role"
            className='border border-gray-300 rounded p-2 w-full'
            required
          >
            <option value="" disabled>Seleccione un rol</option>
            <option value="admin">Admin</option>
            <option value="generic">Generic</option>
          </select>
        </div>
        <button
          type="submit"
          className='bg-cyan-500 text-white py-2 px-4 rounded-md font-bold mt-4'
        >
          Save
        </button>
      </form>
    </div>
    </>
  )
}
