import React from 'react';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import Usuarios from '../api/usuarios';

export default function Menu() {
  const navigate = useNavigate();

  return (
    <>
      <div className='relative h-screen'>
        <nav className='fixed border border-gray-700 h-screen w-60 flex flex-col'>
          <ul className='flex flex-col flex-grow'>
            <li className='hover:bg-cyan-500 w-full border-b border-gray-700'>
              <Link to="#" className='block text-gray-700 text-center py-2 font-semibold hover:text-white'>Menu</Link>
            </li>
            <li className='hover:bg-cyan-500 border-b border-gray-700 w-full'>
              <Link to="#" className='block text-gray-700 text-center py-2 font-semibold hover:text-white'>Seguridad</Link>
            </li>
            <li className='hover:bg-cyan-500 border-b border-gray-700 w-full'>
              <Link to="#" className='block text-gray-700 text-center py-2 font-semibold hover:text-white'>Usuarios</Link>
            </li>
          </ul>
          <div className='hover:bg-cyan-500 border-t border-gray-700 w-full py-2 mt-auto'>
            <Link to="#" className='block text-gray-700 hover:text-white text-center font-semibold'>Footer</Link>
          </div>
        </nav>
        
      </div>

      <div className='fixed top-0 right-0 p-4 flex flex-col mr-20 items-end space-y-20'>
        <input
          type="text"
          placeholder='Search'
          className='border border-gray-700 rounded p-2 mt-8'
        />
        {/* Botón "Nuevo Usuario" */}
        <button className='bg-cyan-500 py-2 px-6 rounded-md text-white font-semibold' onClick={()=>navigate("/createduser")}>
          Nuevo <br /> Usuario
        </button>
        {/* Contenedor del Listado de Usuarios */}
        <div className='w-[600px] h-72 border border-gray-700  mr-80 flex items-center justify-center'>
          <Usuarios/>
        </div>
      </div>
    </>
  );
}
