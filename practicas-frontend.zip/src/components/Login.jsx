import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const navigate = useNavigate();
  const handleSubmit = (event) => {
    event.preventDefault();
    navigate("/dashboard")
  };

  return (
    <div className='border border-gray-700 p-4 max-w-lg mx-auto mt-28 '>
      <h1 className='text-2xl font-bold mb-4 border-b pb-1'>Sign In</h1>
      <form onSubmit={handleSubmit}>
        <div className='mb-4'>
          <label htmlFor="name" className='block text-sm font-medium mb-1 text-gray-700'>User Name</label>
          <input 
            id='name' 
            type="text" 
            placeholder='User Name' 
            className='border rounded-md p-2 w-full'
            required
          />
        </div>
        <div className='mb-4'>
          <label htmlFor="password" className='block text-sm font-medium mb-1 text-gray-700'>Password</label>
          <input 
            id='password' 
            type="password" 
            placeholder='Password' 
            className='border rounded-md p-2 w-full'
            required
          />
        </div>
        <button 
          type="submit"
          className='bg-cyan-500 p-2 ml-3 rounded-md text-white font-bold cursor-pointer uppercase'
        >
          sign in
        </button>
        <div className='mt-4 border-b pb-3'>
          <a href="#" className='text-blue-500 underline'>Forgot Password?</a>
        </div>
        
      </form>
      <div className='mt-5'>
          <p className='text-gray-700'>New User</p>
          <button 
          
          className='bg-cyan-500 p-2 mt-2 ml-3 rounded-md text-white font-bold cursor-pointer uppercase'
        >
          <a href="#">sign up</a>
        </button>
        </div>
    </div>
  );
}
