import { useState, useEffect } from "react";

export default function Usuarios() {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetch("http://localhost:4000/api/usuarios")
            .then(response => {
                if (response.headers.get('Content-Type')?.includes('application/json')) {
                    return response.json();
                } else {
                    throw new Error('Expected JSON response');
                }
            })
            .then(data => {
                console.log('Data received:', data);
                setData(data.body || []); 
                setLoading(false);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
                setError(error);
                setLoading(false);
            });
    }, []);

    if (loading) return <p>Cargando...</p>;
    if (error) return <p>Error: {error.message}</p>;

    return (
        <div className="flex flex-col items-center">
        
            {data && data.length > 0 ? (
                <div>
                    <h1 className="text-center bg-cyan-700 text-white rounded">Usuarios</h1>

                    <div className="flex gap-4">
                        <div className="flex flex-col">
                            <p>Name</p>
                            <p>Email</p>
                            <p>Status</p>
                            <p>User Name</p>
                        </div>
                        {data.map(user => (
                            <div key={user.id}>
                                <div>
                                    <p>{user.name}</p>
                                </div>
                                <div>
                                    <p>{user.email}</p>
                                </div>
                                <div>
                                    {
                                        user.status === 0 ?(
                                            <p>generico</p>
                                            
                                        ):(
                                            <p>admin</p>

                                        )
                                    }
                                </div>
                                <div>
                                    <p>{user.username}</p>
                                </div>
                            </div>
                          

                           
                        ))}
                    </div>
                </div>
               
            ) : (
                <p>No hay usuarios disponibles</p>
            )}

        </div>
    );
}
