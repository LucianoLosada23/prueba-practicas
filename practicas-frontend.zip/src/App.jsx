// App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Dashboard from './page/Dashboard';
import Home from './page/Home';
import CreatedUser from './page/CreatedUser';
import Usuarios from './api/usuarios';
function App() {
  return (
    <>
      <Router>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/Home" element={<Home/>} />
        <Route path="/createduser" element={<CreatedUser/>} />
        <Route path="/" element={<Navigate to="/Home" replace />} />
        {/* Agrega más rutas acá */}
      </Routes>
    </Router>
    </>
  
  );
}

export default App;
