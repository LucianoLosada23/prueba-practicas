import React from 'react';
import User from '../components/User';
export default function CreatedUser() {
  return (
   <>
   <User/>
   </>
  );
}
